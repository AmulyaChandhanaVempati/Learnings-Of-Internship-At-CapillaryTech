package DifferentBeforeAfters;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class TryingDataProvider{
	@Test(dataProvider="param_dataProvider")
	private void UsingDP(String str) {
		System.out.println("OP: "+str);
	}
	
	@DataProvider (name = "param_dataProvider")
	public Object[][] MethodDP(){
		return new Object[][] { {"Amulya"},{"Keerthi"},{"Nikhitha"},{"Sree"},{"Rahul"}};
		
	}
}
