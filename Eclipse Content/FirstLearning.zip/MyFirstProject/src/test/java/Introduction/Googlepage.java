package Introduction;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
public class Googlepage {
	
	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Amulya Chandhana V\\Downloads\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.google.co.in/");
		Thread.sleep(5000);
		// to maximize the browser window
		driver.manage().window().maximize();
		String title = driver.getTitle();
		System.out.println("title: "+title );
		if(title.equals("Amulya")) {
			System.out.println("Google page is not displayed , test case failed");
		}
		else {
			System.out.println("Google page is displayed, test case passed");
		}
		Thread.sleep(3000);
		driver.close();
		
	}

}