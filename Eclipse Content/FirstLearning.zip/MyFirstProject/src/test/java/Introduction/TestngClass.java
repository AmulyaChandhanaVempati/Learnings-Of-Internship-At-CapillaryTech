package Introduction;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class TestngClass {
	private WebDriver driver;
	String URL = "https://www.google.co.in/";
	@BeforeClass
	public void testsetup() {
		System.setProperty("webdriver.chrome.driver", "C:\\\\Users\\\\Amulya Chandhana V\\\\Downloads\\\\chromedriver.exe");
		driver = new ChromeDriver();
	}
	@Test
	public  void verifygooglepagetitle() {
		driver.get(URL);
		String title = driver.getTitle();
		Assert.assertEquals(title, "Google");
	}
	@AfterClass
	public void closewindow() {
		driver.close();
	}

}
