package Introduction;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class WritingTestCases {
	
	WebDriver driver = null;
	
	@BeforeMethod
	public void loadWebDtiver() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Amulya Chandhana V\\Downloads\\chromedriver.exe");
		driver =  new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.w3schools.com/");
		System.out.println("Title: "+driver.getTitle());
	}
	//TDD
	
	@Test
	public void TestCase1_checkTitle() {
		String title = driver.getTitle();
		boolean a = driver.getTitle().contains("Web Tutorials");
		Assert.assertTrue(a);
	}
	
	@Test
	public void TestCase2_ChecKTextForWorongCredentials() throws InterruptedException {
		driver.findElement(By.xpath("//a[@class='w3-bar-item w3-btn w3-right']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@class='_ZsgaF undefined']")).sendKeys("capillarytech.com");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@id='current-password']")).sendKeys("AmulyaChandhana");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//button[@class='_1VfsI _OD95i _3_H0V']")).click();
		Thread.sleep(2000);
		driver.findElement(By.className("_2rXkA"));
		Thread.sleep(2000);	
	}
	
	@Test
	public void TestCase3_checkShowHide() throws InterruptedException {
		driver.findElement(By.xpath("//a[@class='w3-bar-item w3-btn w3-right']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//span[@class='_8HgG3']")).click();
		Thread.sleep(2000);
		 driver.findElement(By.xpath("//span[text()=' Hide ']"));
		Thread.sleep(2000);	
		
	}
	
	@Test
	public void TestCase4_checkMenu() throws InterruptedException {
		driver.findElement(By.xpath("//a[@class='w3-bar-item w3-button w3-hide-small barex bar-item-hover w3-padding-24']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//h3[text()='HTML and CSS']"));
		Thread.sleep(2000);	
		
	}
	
	
	@Test
	public void TestCase5_checkVideo() throws InterruptedException {
		driver.findElement(By.xpath("//a[@class='w3-button ws-yellow tut-button ws-yellow-hover']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//div[@class='vjs-poster']")).click();
		Thread.sleep(2000);	
		
	}
	@AfterMethod
	public void closeWebDriver() {
		driver.quit();
	}
	
	
	/*Scenario: validating user login 
    Given user is on login page
    When User enters valid username and Password
    And click on login button
    Then user is navigated to home page
    
Scenario: User inside  the website
    Given User is on the Home Page 
    And click on Capillary Technologies Menu Bar
    And Search for fnb organisation
    And click on REON_DATA_FnB
    And click on bread Crumbs
    And click on Insights+
    Then user is navigated to Report page
    And Search for a report
    And click on the report
    And Click on the profile
    And Click on log Out 
    And Close the window*/




	

}
