package StepDefinitions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.asserts.SoftAssert;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Report {
	
	WebDriver driver;
	SoftAssert sa = new SoftAssert();
	
	@Given("User is on login page")
	public void user_is_on_login_page() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Amulya Chandhana V\\Downloads\\chromedriver.exe");
		driver =  new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://crm-nightly-new.cc.capillarytech.com/");
	}

	@When("User enters valid username and Password #Action")
	public void user_enters_valid_username_and_password_action() {
		driver.findElement(By.xpath("//input[@id='login_user']")).sendKeys("ashish");
		driver.findElement(By.xpath("//input[@id='login_cred']")).sendKeys("123");
	}

	@When("click on login button # other action")
	public void click_on_login_button_other_action() {
		driver.findElement(By.xpath("//input[@id='c-login-btn']")).click();
	}

	@Then("user is navigated to home page # expected output")
	public void user_is_navigated_to_home_page_expected_output() {
		String hometitle = driver.getTitle();
		System.out.println("Title of the page : "+hometitle);
		//Assert.assertEquals(hometitle,"Capillary InTouch >> Workbenchy");
		sa.assertEquals(hometitle,"Capillary InTouch >> Workbenchy");
	}

	@When("User clicks on Capillary Technologies drop down")
	public void user_clicks_on_capillary_technologies_drop_down() {
		driver.findElement(By.xpath("//span[@class='intouch-nav-selected-org-label']")).click();
	}

	@When("search for fnb organisation")
	public void search_for_fnb_organisation() {
		driver.findElement(By.xpath("//input[@id='org-search-div']")).sendKeys("fnb");
	}

	@When("Click on REON_DATA_FnB")
	public void click_on_reon_data_fn_b() {
		driver.findElement(By.xpath("//li[text()='REON_DATA_FnB']")).click();
	}

	@Then("User is navigated to REON_DATA_FnB page")
	public void user_is_navigated_to_reon_data_fn_b_page() {
		 WebElement hometitle = driver.findElement(By.xpath("//span[@class='intouch-nav-selected-org-label']"));
		 
			System.err.println("WebElement: "+hometitle.getText());
			sa.assertEquals(hometitle.getText(),"REON_DATA_FnB");
	}

	@When("User clicks on bread Crumbs")
	public void user_clicks_on_bread_crumbs() {
		driver.findElement(By.xpath("//div[@class='intouch-nav-heading']")).click();
	}

	@When("clicks on Insights+")
	public void clicks_on_insights() throws InterruptedException {
		driver.findElement(By.xpath("//li[text()='Insights+ ']")).click();
	    Thread.sleep(5000);
	}

	@Then("User is navigated to Report page")
	public void user_is_navigated_to_report_page() {
		String PageTitle = driver.getTitle();
		 System.out.println("Tilte : "+ PageTitle);
		 sa.assertEquals(PageTitle, "Reports");
	}

	@When("User Search for a report")
	public void user_search_for_a_report() throws InterruptedException {
		Thread.sleep(3000);
		driver.findElement(By.xpath("//a[@id='pushActionRefuse']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Search reports']")).click();
	  driver.findElement(By.xpath("//input[@placeholder='Search reports']")).sendKeys("Test_reportsui");
	}

	@When("clicks on the report")
	public void clicks_on_the_report() {
		driver.findElement(By.xpath("//span[@class='normal-text']")).click();
	}

	@When("User is on the selected Report page")
	public void User_is_on_the_selected_Report_page() throws InterruptedException {
		Thread.sleep(3000);
		String Reporttitle = driver.getTitle();
		System.out.println("Title of the page : "+Reporttitle);
		sa.assertEquals(Reporttitle,"Reports");
	}
	
	@When("User clicks on calender")
	public void User_clicks_on_calender() throws InterruptedException {
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[@class='date-range']")).click();
	}
	
	@When("Clicks on To Date Option")
	public void Clicks_on_To_Date_Option() throws InterruptedException {
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[@class=' ant-tabs-tab'][1]")).click();
	}
	
	@When("Clicks on Month Till Date")
	public void Clicks_on_Month_Till_Date() throws InterruptedException {
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@value='month']")).click();
	}
	
	@When("Clicks on Compare time period")
	public void Clicks_on_Compare_time_period() throws InterruptedException {
		Thread.sleep(1000);
		driver.findElement(By.xpath("//span[text()='Compare time period']")).click();
	}
	
	@When("Clicks on Same month of last year")
	public void Clicks_on_Same_month_of_last_year() throws InterruptedException {
		Thread.sleep(1000);
		driver.findElement(By.xpath("//span[text()='Same month of last year']")).click();
	}
	@When("Turns On View Common Stores")
	public void Turns_On_View_Common_Stores() throws InterruptedException {
		Thread.sleep(1000);
		driver.findElement(By.xpath("//button[@class='cap-switch-v2 ant-switch']")).click();
	}
	
	@When("Clicks on Apply")
	public void Clicks_on_Apply() throws InterruptedException {
		Thread.sleep(1000);
		driver.findElement(By.xpath("//button[@id='applyDateFiter']")).click();
	}
	
	@When("User goes back to the report page")
	public void User_goes_back_to_the_report_page() throws InterruptedException {
		Thread.sleep(8000);
		driver.findElement(By.xpath("//i[@title='Back to all reports']")).click();
		Thread.sleep(3000);
	}

/*	@When("clicks on the profile")
	public void clicks_on_the_profile() {
		driver.findElement(By.xpath("//i[@class='anticon cap-icon-v2 cap-icon-v2-person cap-navbar-person CapIcon__AntIcon-sc-52535-0 dAqpdr']")).click();
	}

	@When("Click on log Out")
	public void click_on_log_out() {
		driver.findElement(By.xpath("//div[text()='Logout']")).click();
	}

	@Then("User is is navigated to login page")
	public void user_is_is_navigated_to_login_page() {
		String title = driver.getTitle();
		System.out.println("Title of the page : "+title);
		sa.assertEquals(title,"Login | Capillary Technologies");
	}

	@Then("Close the window")
	public void close_the_window() throws InterruptedException {
		Thread.sleep(3000);
		driver.close();
		sa.assertAll();   
	}

	*/


}
