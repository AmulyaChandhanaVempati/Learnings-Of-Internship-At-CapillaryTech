package StepDefinitions;


import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.CucumberFeatureWrapper;
import cucumber.api.testng.TestNGCucumberRunner;

@CucumberOptions(
        features = "src/test/resources/",
        glue = { "StepDefinitions/Report.java"
    	 },
        tags = {"@Report"},
        monochrome =true
       )
public class TestRunner
{
 private TestNGCucumberRunner testNGCucumberRunner;
 
 
  @Test(dataProvider = "features")
  public void feature(CucumberFeatureWrapper cucumberFeature) throws Exception {
     try
     {
	  testNGCucumberRunner.runCucumber(cucumberFeature.getCucumberFeature());
     }
     catch(org.openqa.selenium.NoSuchElementException e)
     {
    	 e.printStackTrace();
     }
//      DriverUtil.driver.quit();
  }
  @DataProvider()
  public Object[][] features() {
  	 return testNGCucumberRunner.provideFeatures();
  }
 
 
}















/*import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;
import io.cucumber.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features="src/test/resources/features", glue= {"StepDefinitions"})
public class TestRunner {
}
*/
