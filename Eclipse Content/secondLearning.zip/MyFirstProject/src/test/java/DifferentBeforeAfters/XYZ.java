package DifferentBeforeAfters;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class XYZ {
	
	@BeforeTest
	public void BeforeTest() {
		System.out.println("Before Test !!!");
	}
	@BeforeClass
	public void BeforeClass() {
		System.out.println("Class XYZ = Before Class!");
	}
	@BeforeMethod
	public void BeforeMethod() {
		System.out.println("Class XYZ = Before Method!");
	}
	
	@Test
	public void test1() {
		System.out.println("Class XYZ = Test 1");
	}
	@Test
	public void test2() {
		System.out.println("Class ABC = Test 2");
	}
	@Test
	public void test3() {
		System.out.println("Class ABC = Test 3");
	}
	@AfterMethod
	public void AfterMethod() {
		System.out.println("Class XYZ = After Method!");
	}
	
	@AfterClass
	public void AfterClass() {
		System.out.println("Class XYZ = After Class!");
	}
	@AfterTest
	public void AfterTest() {
		System.out.println("After Test !!!");
	}

}
