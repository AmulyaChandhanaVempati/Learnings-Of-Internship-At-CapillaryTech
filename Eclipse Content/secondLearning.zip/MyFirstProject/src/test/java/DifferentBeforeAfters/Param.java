package DifferentBeforeAfters;


import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class Param {
	
	  @Parameters("AmulyaChandhana")
	 
	  @Test public void inLineParameter(String value) {
	  System.out.println("Output: "+value); }
	 
	
}
