package DifferentBeforeAfters;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class XYZ1 {
	
	@BeforeClass
	public void BeforeClass() {
		System.out.println("Class XYZ1 = Before Class!");
	}
	@BeforeMethod
	public void BeforeMethod() {
		System.out.println("Class XYZ1 = Before Method!");
	}
	
	@Test
	public void test1() {
		System.out.println("Class XYZ1 = Test 1");
	}
	@Test
	public void test2() {
		System.out.println("Class XYZ1 = Test 2");
	}
	@Test
	public void test3() {
		System.out.println("Class XYZ1 = Test 3");
	}
	@AfterMethod
	public void AfterMethod() {
		System.out.println("Class XYZ1 = After Method!");
	}
	
	@AfterClass
	public void AfterClass() {
		System.out.println("Class XYZ1 = After Class!");
	}

}
